<?php

Route::prefix('api/v1')->group(function () {
	Route::post('signin', 'Igniter\\Api\\Controllers\\Customers@signin');
	Route::post('signup', 'Igniter\\Api\\Controllers\\Customers@signup');
	Route::post('set_location', 'Igniter\\Api\\Controllers\\Customers@set_location');
});