<?php

namespace Igniter\Api\Controllers;

use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Geocoder;
use Location;
use AdminMenu;
use Hash;

use Igniter\Local\Traits\SearchesNearby;
/**
 * Customers Admin Controller
 */
class Customers extends \Admin\Classes\AdminController
{
    use SearchesNearby;
    public $implement = [
        'Admin\Actions\FormController',
        'Admin\Actions\ListController'
    ];

    public $listConfig = [
        'list' => [
            'model' => 'Admin\Models\Customers_model',
            'title'        => 'Customers',
            'emptyMessage' => 'lang:admin::lang.list.text_empty',
            'defaultSort'  => ['id', 'DESC'],
            'configFile'   => 'customer',
        ],
        'location' => [
            'model' => 'Admin\Models\Locations_model',
            'title'        => 'Locations',
            'emptyMessage' => 'lang:admin::lang.list.text_empty',
            'defaultSort'  => ['id', 'DESC'],
            'configFile'   => 'location',
        ],
    ];

    public $formConfig = [
        'name'       => 'Customers',
        'model'      => 'Igniter\Api\Models\Customer',
        'create'     => [
            'title'         => 'lang:admin::lang.form.create_title',
            'redirect'      => 'igniter/api/customers/edit/{id}',
            'redirectClose' => 'igniter/api/customers',
        ],
        'edit'       => [
            'title'         => 'lang:admin::lang.form.edit_title',
            'redirect'      => 'igniter/api/customers/edit/{id}',
            'redirectClose' => 'igniter/api/customers',
        ],
        'preview'    => [
            'title'    => 'lang:admin::lang.form.preview_title',
            'redirect' => 'igniter/api/customers',
        ],
        'delete'     => [
            'redirect' => 'igniter/api/customers',
        ],
        'configFile' => 'customer',
    ];

    protected $requiredPermissions = 'Igniter.Api';

    public function __construct()
    {
        parent::__construct();

        AdminMenu::setContext('customers', 'igniter.api');
    }

    public function setCustomerResponse($model, $request)
    {
        if($request['userId'])
            $customer = $model->where('customer_id', $request['userId'])->first();
        else
            $customer = $model->where('email', $request['email'])->first();
        if($customer)
        {
            $response['token'] = $customer->remember_token;
            $response['user'] = [
                'id' => $customer->customer_id,
                'first_name' => $customer->first_name,
                'last_name' => $customer->last_name,
                'full_name' => $customer->first_name . ' ' . $customer->last_name,
                'telephone' => $customer->telephone,
                'address_1' => ($customer->addresses->count() != 0) ? $customer->addresses[0]['address_1'] : '',
                'address_2' => ($customer->addresses->count() != 0) ? $customer->addresses[0]['address_2'] : '',
                'city' => ($customer->addresses->count() != 0) ? $customer->addresses[0]['city'] : '',
                'state' => ($customer->addresses->count() != 0) ? $customer->addresses[0]['state'] : '',
                'postcode' => ($customer->addresses->count() != 0) ? $customer->addresses[0]['postcode'] : '',
                'country_id' => ($customer->addresses->count() != 0) ? $customer->addresses[0]['country_id'] : '',
            ];
            Log::debug($response);
        }
        else {
            abort(429, lang('admin::lang.login.alert_fail_signin'));
        }
        return $response;
    }

    public function signin(Request $request)
    {
        $modelClass = $this->listConfig['list']['model'];
        $model = new $modelClass;

        if($model->where('email', $request['email'])->count() > 0) {
            // this means that exist user
            if(Hash::check($request['password'], $model->where('email', $request['email'])->first()->password))
            {
                $remember_token = $this->generateRandomString(42);
                $model->where('email', $request['email'])->update(['remember_token' => $remember_token]);
                $response = $this->setCustomerResponse($model, $request);
            } else
            {
                abort(429, lang('admin::lang.login.alert_fail_signin'));
            }
        } else {
            abort(429, lang('admin::lang.login.alert_fail_signin'));
        }
        return $response;
    }

    public function generateRandomString($length) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function isValidCustomer($request) {
        $modelClass = $this->listConfig['list']['model'];
        $model = new $modelClass;
        if($model->where('customer_id', $request['userId'])->where('remember_token', $request['token'])->count() > 0)
        {
            return true;
        }
        return false;
    }

    public function signup(Request $request) {
        $modelClass = $this->listConfig['list']['model'];
        $model = new $modelClass;
        $request['password'] = Hash::make($request['password']);
        if($model->where('email', $request['email'])->count() > 0) {
            // this means that exist user
            abort(429, lang('admin::lang.login.alert_useremail_duplicated'));
        } else {
            $model->insertOrIgnore($request->toArray());
            $response = $this->setCustomerResponse($model, $request);
            return $response;
        }
    }

    public function set_location(Request $request) {

        if(! $this->isValidCustomer($request)) 
            abort(429, lang('admin::lang.login.alert_user_expired'));

        try {
            $userLocation = $this->geocodeSearchQuery($request->houseNumber . ' ' . $request->postCode);
            if($userLocation->getLocality)
            $nearByLocation = Location::searchByCoordinates(
                $userLocation->getCoordinates()
            )->first(function ($location) use ($userLocation) {
                if ($area = $location->searchDeliveryArea($userLocation->getCoordinates())) {
                    Location::updateNearbyArea($area);
                    return $area;
                }
            });
            if (!$nearByLocation) {
                abort(429, lang('admin::lang.login.alert_not_correct_location'));
            }
        }
        catch (Exception $ex) {
            abort(429, lang('admin::lang.login.alert_not_correct_location'));
        }

        $modelClass = $this->listConfig['list']['model'];
        $model = new $modelClass;

        $customer = $model->where('customer_id', $request['userId'])->first();

        Log::debug($request->address);
        $customer->addresses()->delete();
        $customer->addresses()->insert($request->address);

        $response = $this->setCustomerResponse($model, $request);
        return $response;
    }
}
